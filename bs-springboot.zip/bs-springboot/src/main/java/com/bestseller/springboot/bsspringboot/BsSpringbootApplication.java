package com.bestseller.springboot.bsspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BsSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BsSpringbootApplication.class, args);
	}

}
